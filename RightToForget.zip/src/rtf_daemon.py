"""
Right-to-Forget Daemon
"""

import time
from datetime import datetime, timedelta

class RightToForgetDaemon:
    def __init__(self, ttl_seconds=3600):
        self.memory_registry = {}  # {event_id: (timestamp, context_tag)}
        self.ttl = timedelta(seconds=ttl_seconds)

    def register_event(self, event_id, context_tag="generic"):
        self.memory_registry[event_id] = (datetime.now(), context_tag)

    def forget_expired(self):
        now = datetime.now()
        expired = [eid for eid, (ts, _) in self.memory_registry.items() if now - ts > self.ttl]
        for eid in expired:
            del self.memory_registry[eid]
        return expired

    def current_memory(self):
        return list(self.memory_registry.keys())
