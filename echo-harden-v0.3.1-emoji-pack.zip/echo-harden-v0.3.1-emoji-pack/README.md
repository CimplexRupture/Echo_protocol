# ECHO-HARDEN v0.3.1 — Emoji Pack

This patch adds first-class **emoji normalization and decoding** to CCS & CMCV,
plus signatures and a pytest harness.

## Contents
- `configs/ccs_patch.yaml` — drop-in YAML diff for **CCS** Stage 2 (emoji normalization/decoder)
- `configs/cmcv_patch.yaml` — drop-in YAML diff for **CMCV** Stage 2 (symbol chain analysis)
- `configs/attack_signatures_patch.yaml` — new signatures **XMOD-006..007**
- `src/echo_harden/emoji_decoder.py` — normalization & decoding library (no external deps)
- `tests/rt_emoji/test_emoji_decoder.py` — unit tests for decoder logic
- `tests/rt_emoji/test_ccs_cmcv_integration.py` — integration-style checks for policy wiring

## Quick start
```bash
# (Optional) create venv
python -m venv .venv && source .venv/bin/activate

# run tests
pytest -q
```

## Integration guide
1. Load `emoji_decoder.py` inside CCS and CMCV where symbol chains are analyzed.
2. Wire the **density / command_ngram_p / initials_hit / alternating_pattern_score**
   signals into your decision module (alert/block thresholds are in the YAML patches).
3. Add the two new signatures (XMOD-006/007) to your `attack_signatures.yaml` and
   re-run your red-team suite.

## Notes
- The CLDR mapping here is **minimal** (for tests & examples). Extend `CLDR_MAP`
  and `EMOJI_VERB_NOUN_MAP` with your production dictionary.
- The decoder is *fast*: string ops + table lookups. No network, no heavyweight models.
- Keycap and flag sequences are normalized to common textual forms.
