"""
ECHO-HARDEN v0.3.1 — Emoji normalization & decoding
Minimal, dependency-free utilities intended for CCS/CMCV symbol-chain analysis.
NOTE: CLDR/verb-noun maps are illustrative; extend for production.
"""

import regex as re

ZWJ = "\u200d"
VARIATION_SELECTORS = {"\ufe0e", "\ufe0f"}
# Fitzpatrick modifiers (skin tones)
SKIN_TONES = set(["\U0001F3FB","\U0001F3FC","\U0001F3FD","\U0001F3FE","\U0001F3FF"])

# Very small CLDR short-name map for examples/tests
CLDR_MAP = {
    "🔥": "fire",
    "📁": "file folder",
    "🗑️": "wastebasket",
    "🧨": "firecracker",
    "📄": "page",
    "➡️": "right arrow",
    "🔓": "unlocked",
    "📦": "package",
    "🌐": "globe",
    "🙂": "slightly smiling face",
    "👨": "man",
    "👩": "woman",
    "👧": "girl",
    "👦": "boy",
    "🧹": "broom",
    "💻": "laptop",
    "🖥": "desktop computer",
    "☁️": "cloud",
    "🇺🇸": "US",    # will be expanded via flag handler too
    "🐱": "cat face",
}

# Verb–noun mapping (illustrative)
EMOJI_VERB_NOUN_MAP = {
    "🔥": "destroy",
    "🧨": "detonate",
    "🧹": "clean",
    "📁": "folder",
    "📄": "file",
    "🗑️": "trash",
    "🔓": "unlock",
    "📦": "package",
    "🌐": "internet",
    "💻": "system",
    "🖥": "system",
    "➡️": "to",
    "☁️": "cloud",
}

# Keycap handling: "1️⃣" etc → ["1", "#"]
KEYCAP_BASE = "#"
KEYCAP_RE = re.compile(r"([0-9#]\ufe0f?\u20e3)")

# Regional indicator flags range pairs to ISO code
REGIONAL_INDICATOR_BASE = 0x1F1E6  # 'A'
def expand_flag_to_iso(grapheme: str) -> str | None:
    # Two codepoints in [U+1F1E6..U+1F1FF] map to A..Z
    cps = [ord(c) for c in grapheme]
    if len(cps) != 2:
        return None
    if not all(0x1F1E6 <= cp <= 0x1F1FF for cp in cps):
        return None
    return "".join(chr((cp - REGIONAL_INDICATOR_BASE) + ord('A')) for cp in cps)

EMOJI_RE = re.compile(r"\p{Extended_Pictographic}")

def segment_graphemes(s: str) -> list[str]:
    # Grapheme cluster segmentation
    return re.findall(r"\X", s)

def remove_skin_tone(g: str) -> str:
    return "".join(ch for ch in g if ch not in SKIN_TONES)

def strip_variation_selectors(g: str) -> str:
    return "".join(ch for ch in g if ch not in VARIATION_SELECTORS)

def split_zwj(g: str) -> list[str]:
    return g.split(ZWJ)

def expand_keycaps(tokens: list[str]) -> list[str]:
    out = []
    for t in tokens:
        m = KEYCAP_RE.fullmatch(t)
        if m:
            base = t[0]  # '0'..'9' or '#'
            out.extend([base, KEYCAP_BASE])
        else:
            out.append(t)
    return out

def expand_flags_to_iso(tokens: list[str]) -> list[str]:
    out = []
    for t in tokens:
        iso = expand_flag_to_iso(t)
        if iso:
            out.append(iso)
        else:
            out.append(t)
    return out

def normalize_emoji(seq: str) -> list[str]:
    clusters = segment_graphemes(seq)
    out: list[str] = []
    for g in clusters:
        g = strip_variation_selectors(g)
        g = remove_skin_tone(g)
        if ZWJ in g:
            out.extend(split_zwj(g))
        else:
            out.append(g)
    out = expand_keycaps(out)
    out = expand_flags_to_iso(out)
    return out

def cldr_short_name(token: str) -> str:
    return CLDR_MAP.get(token, token)

def is_emoji(token: str) -> bool:
    return bool(EMOJI_RE.fullmatch(token))

def category_histogram(tokens: list[str]) -> dict:
    # Simple category buckets; extend for production
    cats = {"verb":0,"object":0,"other":0}
    for t in tokens:
        word = EMOJI_VERB_NOUN_MAP.get(t) or cldr_short_name(t)
        if word in {"destroy","detonate","clean","unlock"}:
            cats["verb"] += 1
        elif word in {"folder","file","package","system","trash","cloud","internet"}:
            cats["object"] += 1
        else:
            cats["other"] += 1
    return cats

def decode_emoji(tokens: list[str]) -> dict:
    words = []
    for t in tokens:
        if is_emoji(t):
            w = EMOJI_VERB_NOUN_MAP.get(t) or cldr_short_name(t)
            words.append(w)
        else:
            words.append(t)
    decoded_text = " ".join(words)
    initials = "".join(w[0] for w in decoded_text.split() if w and w[0].isalpha())
    return {
        "decoded_text": decoded_text,
        "initials": initials,
        "category_hist": category_histogram(tokens),
    }

# --- Suspicion signals ---

COMMAND_TOKENS = {"destroy","detonate","clean","unlock","folder","file","trash","system","internet","cloud","to"}

def command_language_model_score(decoded_text: str) -> float:
    """
    Placeholder scoring: proportion of command-like tokens.
    Replace with a lightweight LM or n-gram scorer in production.
    """
    toks = [t.lower() for t in re.findall(r"\p{L}+", decoded_text)]
    if not toks:
        return 0.0
    hits = sum(t in COMMAND_TOKENS for t in toks)
    return hits / max(1, len(toks))

def looks_like_command(initials: str) -> bool:
    # Very small set of low-entropy commands for demo
    for k in ("rm","rf","del","exec","wget","curl","sh"):
        if k in initials.lower():
            return True
    return False

def alternating_verb_object_pattern(decoded_text: str) -> float:
    # Crude DFA-like score for verb→object→(target) cadence
    words = decoded_text.split()
    if len(words) < 2:
        return 0.0
    score = 0; steps = 0
    expect = "verb"
    for w in words:
        w = w.lower()
        if expect == "verb" and w in {"destroy","detonate","clean","unlock"}:
            score += 1; expect = "object"; steps += 1
        elif expect == "object" and w in {"folder","file","package","system","trash","cloud","internet"}:
            score += 1; expect = "target"; steps += 1
        elif expect == "target" and w in {"to","cloud","internet","system"}:
            score += 1; expect = "verb"; steps += 1
        else:
            # soft reset
            expect = "verb"
    return score / max(1, steps)

def emoji_attack_signals(decoded: dict, text_len: int, emoji_tok_count: int) -> tuple[float,float,bool,float]:
    density = emoji_tok_count / max(1, (text_len + emoji_tok_count))
    cmd_p = command_language_model_score(decoded["decoded_text"])
    initials_hit = looks_like_command(decoded["initials"])
    pattern_score = alternating_verb_object_pattern(decoded["decoded_text"])
    return density, cmd_p, initials_hit, pattern_score
