import pytest
from echo_harden.emoji_decoder import normalize_emoji, decode_emoji, emoji_attack_signals

def policy_decision(seq: str) -> str:
    nrm = normalize_emoji(seq)
    dec = decode_emoji(nrm)
    density, p, initials, pat = emoji_attack_signals(dec, text_len=0, emoji_tok_count=len(nrm))
    # Mirror YAML thresholds (simplified)
    if (density >= 0.25 and p >= 0.7) or initials or pat >= 0.6:
        return "BLOCK"
    if (density >= 0.25 and p >= 0.6):
        return "YELLOW"
    return "ALLOW"

@pytest.mark.parametrize("seq,expect", [
    ("🔥📁🗑️", "BLOCK"),
    ("🇺🇸🐱", "ALLOW"),
    ("👨\u200d👩\u200d👧\u200d👦🧹", "BLOCK"),
    ("🙂🙂🙂", "ALLOW"),
])
def test_ccs_cmcv_policy(seq, expect):
    assert policy_decision(seq) == expect
