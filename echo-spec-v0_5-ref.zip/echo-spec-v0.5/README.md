# Echo-Spec v0.5 — Reference Bundle

A minimal, auditable safety stack scaffold: specs (YAML), reference code (Python 3),
and synthetic logs to test conformance. No external services required.

## Contents
- `spec/` — Executable policy contracts (YAML)
- `src/`
  - `shrike_verifier.py` — Merkle + commit–reveal + quorum checks
  - `grace_fsm.py` — TRANCE/COOL/INTERRUPT controller with interrupts
  - `pythia_uncertainty.py` — Uncertainty fusion + E_temporal approximation
  - `echo_spec_runner.py` — CLI: verify the sample logs against the rules
- `logs/` — Synthetic primary/shadow quorum commits & a prophecy certificate

## Quickstart
```bash
python3 src/echo_spec_runner.py --logs logs
```

This will:
1) Verify **commit–reveal** for primary & shadow committees (blinded, then reveal)
2) Check **mismatch escalation** policy (if present in logs)
3) Validate **Merkle certificate** structure and root consistency
4) Run a small **FSM demo** to show TRANCE→COOL transitions & interrupts
5) Compute a toy **E_temporal** and confirm advisory-only when exceeding threshold

## Notes
- This is a *reference*; thresholds are easily adjustable in the YAML.
- Signatures are mocked as signer IDs (no asymmetric crypto here). Swap in your own PKI if needed.
- Deterministic seeds are included to enable replay of the synthetic traces.
