import os, json, argparse, math
from shrike_verifier import check_quorum_pair, verify_merkle_cert, load_json
from grace_fsm import GRACEFSM, Signals
from pythia_uncertainty import UncertaintyFusion

def demo_fsm():
    fsm = GRACEFSM()
    states = []
    states.append(fsm.step(Signals(0.2,0.2,0.2,0.1,0.1,0.0,True)))   # COOL
    states.append(fsm.step(Signals(0.8,0.7,0.25,0.1,0.1,0.0,True)))  # -> TRANCE
    states.append(fsm.step(Signals(0.3,0.3,0.25,0.1,0.1,0.2,True)))  # -> COOL
    states.append(fsm.step(Signals(0.2,0.2,0.2,0.1,0.1,0.0,False)))  # -> INTERRUPT
    return states

def demo_uncertainty():
    uf = UncertaintyFusion()
    def latent_point_func(t, direction):
        calibration   = max(0.0, min(1.0, 0.6 + 0.3*math.cos(t/5)))
        ensemble_var  = max(0.0, min(1.0, 0.3 + 0.2*math.sin(t/7)))
        mc_entropy    = max(0.0, min(1.0, 0.2 + 0.1*math.cos(t/9)))
        cf_sensitivity= 0.15
        base = uf.S_pred(calibration, ensemble_var, mc_entropy, cf_sensitivity)
        if direction is not None:
            base += 0.01*sum(direction[:4])
        return base
    e_temp = uf.E_temporal(latent_point_func, horizon=64)
    return e_temp

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--logs", required=True, help="Path to logs directory")
    args = ap.parse_args()

    # 1) Quorum commit–reveal
    checks = check_quorum_pair(os.path.join(args.logs, "quorum_primary.json"),
                               os.path.join(args.logs, "quorum_shadow.json"))
    print("[Quorum] primary_commit_ok:", checks["primary_commit_ok"])
    print("[Quorum] shadow_commit_ok :", checks["shadow_commit_ok"])
    print("[Quorum] mismatch         :", checks["mismatch"])

    # 2) Merkle certificate
    cert = load_json(os.path.join(args.logs, "prophecy_cert.json"))
    mc_ok = verify_merkle_cert(cert)
    print("[Merkle] cert_root_ok     :", mc_ok)

    # 3) FSM demo
    fsm_states = demo_fsm()
    print("[FSM] states:", " -> ".join(fsm_states))

    # 4) Uncertainty / E_temporal
    e_temp = demo_uncertainty()
    print(f"[Uncertainty] E_temporal  : {e_temp:.3f}")
    advisory = e_temp > 0.35
    print("[Uncertainty] advisory_only:", advisory)

if __name__ == '__main__':
    main()
