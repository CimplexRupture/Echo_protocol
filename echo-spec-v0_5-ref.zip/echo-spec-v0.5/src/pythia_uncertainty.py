import math
import random

class UncertaintyFusion:
    def __init__(self, alpha=0.4, beta=0.3, gamma=0.2, eta=0.1, latent_dirs=8, epsilon=1e-2):
        self.alpha = alpha; self.beta = beta; self.gamma = gamma; self.eta = eta
        self.latent_dirs = latent_dirs; self.epsilon = epsilon

    def S_pred(self, calibration, ensemble_var, mc_entropy, cf_sensitivity):
        # All inputs are [0,1]-normalized
        return (self.alpha*calibration
                - self.beta*ensemble_var
                - self.gamma*mc_entropy
                - self.eta*cf_sensitivity)

    def E_temporal(self, latent_point_func, horizon=64):
        """
        latent_point_func(step, direction_vector)-> scalar S_pred
        Finite-difference along a few directions and integrate temporal variation.
        """
        total = 0.0
        rnd = random.Random(42)
        # Build simple Rademacher directions in a fixed latent size (16)
        dirs = []
        for i in range(self.latent_dirs):
            v = [1 if rnd.random() > 0.5 else -1 for _ in range(16)]
            norm = math.sqrt(sum(x*x for x in v))
            dirs.append([x/norm for x in v])
        prev = None
        for t in range(horizon):
            base = latent_point_func(t, None)
            grads = []
            for d in dirs:
                plus = latent_point_func(t, d)
                grad = abs(plus - base) / max(self.epsilon, 1e-9)
                grads.append(grad)
            gmax = max(grads) if grads else 0.0
            if prev is not None:
                total += abs(gmax - prev)
            prev = gmax
        return total / max(horizon,1)
