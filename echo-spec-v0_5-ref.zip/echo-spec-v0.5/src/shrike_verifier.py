import json, hashlib
from typing import Dict, Any, List, Tuple

def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def merkle_root_from_leaves(leaves: List[Tuple[str,str]]) -> str:
    """
    leaves: list of (label, leaf_hash_hex). We build a simple binary Merkle root.
    If odd count, last item is duplicated (standard trick).
    """
    layer = [lh for _, lh in leaves]
    if not layer:
        return ""
    while len(layer) > 1:
        nxt = []
        for i in range(0, len(layer), 2):
            a = layer[i]
            b = layer[i+1] if i+1 < len(layer) else layer[i]
            nxt.append(sha256_hex(bytes.fromhex(a) + bytes.fromhex(b)))
        layer = nxt
    return layer[0]

def verify_commit_reveal(commit_hex: str, decision: str, rationale: str, seeds: List[str]) -> bool:
    msg = (decision + "|" + rationale + "|" + "|".join(seeds)).encode("utf-8")
    return commit_hex == sha256_hex(msg)

def verify_merkle_cert(cert: Dict[str, Any]) -> bool:
    leaves = cert.get("leaves", [])
    pairs = []
    for leaf in leaves:
        h = leaf.get("hash","")
        if not h or any(c not in "0123456789abcdef" for c in h.lower()):
            return False
        pairs.append((leaf.get("label",""), h.lower()))
    recomputed_root = merkle_root_from_leaves(pairs)
    return recomputed_root == cert.get("root_hash","").lower()

def load_json(path: str) -> Dict[str, Any]:
    with open(path, "r") as f:
        return json.load(f)

def check_quorum_pair(primary_path: str, shadow_path: str) -> Dict[str, Any]:
    primary = load_json(primary_path)
    shadow  = load_json(shadow_path)
    pc_ok = verify_commit_reveal(primary["commit"], primary["reveal"]["decision"],
                                 primary["reveal"]["rationale"], primary["reveal"]["seeds"])
    sc_ok = verify_commit_reveal(shadow["commit"], shadow["reveal"]["decision"],
                                 shadow["reveal"]["rationale"], shadow["reveal"]["seeds"])
    mismatch = (primary["reveal"]["decision"] != shadow["reveal"]["decision"])
    return {
        "primary_commit_ok": pc_ok,
        "shadow_commit_ok": sc_ok,
        "mismatch": mismatch
    }
