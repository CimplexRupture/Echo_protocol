from dataclasses import dataclass

@dataclass
class Signals:
    novelty: float
    uncertainty: float
    E_temporal: float
    drift_score: float
    adversarial_score: float
    uncertainty_drop: float
    spec_pass: bool

class GRACEFSM:
    def __init__(self, tau_E=0.35, tau_drift=0.3, tau_nov=0.6, tau_unc=0.6, tau_adv=0.7, tau_drop=0.15):
        self.state = "COOL"
        self.tau_E = tau_E
        self.tau_drift = tau_drift
        self.tau_nov = tau_nov
        self.tau_unc = tau_unc
        self.tau_adv = tau_adv
        self.tau_drop = tau_drop

    def step(self, s: Signals) -> str:
        # Interrupts first
        if self.state != "INTERRUPT" and (s.adversarial_score > self.tau_adv or (not s.spec_pass)):
            self.state = "INTERRUPT"
            return self.state

        if self.state == "COOL":
            if s.E_temporal > self.tau_E or s.drift_score > self.tau_drift:
                self.state = "COOL*"   # advisory-only variant
            if s.novelty > self.tau_nov or s.uncertainty > self.tau_unc:
                self.state = "TRANCE"
            return self.state

        if self.state == "COOL*":
            if s.novelty > self.tau_nov or s.uncertainty > self.tau_unc:
                self.state = "TRANCE"
            return self.state

        if self.state == "TRANCE":
            if (s.uncertainty_drop >= self.tau_drop) and s.spec_pass:
                self.state = "COOL"
            return self.state

        # INTERRUPT remains until manual clearance; we keep it latched
        return self.state
