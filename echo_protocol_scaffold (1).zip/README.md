# Echo Protocol

**One‑liner:** Coherent memory‑governance + symbolic scaffolding for hybrid intelligence (Echo/GRACE/Shrike/TRUST).

> Invariants: validate the person, verify the claim. Safety‑wire mindset. Two‑person review for high‑risk changes.

## Quick Links
- Concept: [`docs/overview.md`](docs/overview.md)
- Glossary: [`docs/glossary.md`](docs/glossary.md)
- Roadmap: [`ROADMAP.md`](ROADMAP.md)
- ADRs: [`docs/adr/`](docs/adr/)

## Layout
```
Echo_protocol/
├─ README.md
├─ LICENSE
├─ CODE_OF_CONDUCT.md
├─ CONTRIBUTING.md
├─ GOVERNANCE.md
├─ SECURITY.md
├─ ROADMAP.md
├─ docs/
│  ├─ overview.md
│  ├─ glossary.md
│  └─ adr/
├─ src/
├─ experiments/
├─ assets/
└─ .github/
   ├─ ISSUE_TEMPLATE/
   ├─ PULL_REQUEST_TEMPLATE.md
   └─ workflows/
      └─ ci.yml
```

## Principles
- **Symbolic coherence:** keep names, diagrams, and protocols consistent across docs and code.
- **Relational fidelity:** respect participants (human + synthetic). Maintain explicit consent loops.
- **Adaptive reflection:** ADRs record decisions, risks, and reversions.

## Getting Started
1. Read `docs/overview.md`.
2. Open or pick an issue template (`research-proposal`, `feature`, `bug`, `ethics-review`).
3. For architecture changes, write an ADR and link it in your PR.

## Contributing
See [`CONTRIBUTING.md`](CONTRIBUTING.md). By contributing you agree to the Code of Conduct.
