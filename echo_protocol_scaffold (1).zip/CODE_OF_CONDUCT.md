# Code of Conduct

We commit to a harassment‑free, respectful collaboration for people of all backgrounds and identities.

## Standards
- Be respectful; assume good faith; no personal attacks.
- Critique ideas, not people.
- No harassment, hate speech, or exclusionary behavior.
- Honor consent: do not use private data without explicit permission.

## Enforcement
- Maintainers may warn, edit, or remove contributions not aligned with this code.
- Repeated or severe violations may result in bans.

## Reporting
- Open a confidential issue or email the maintainers (placeholder).
