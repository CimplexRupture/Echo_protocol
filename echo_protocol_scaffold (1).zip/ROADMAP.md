# Roadmap (living)

## Near‑term (0–3 months)
- Publish core glossary and invariants
- Reference ADRs: capability bounding, memory decay, consent loops
- Minimal schemas in `/src` for memory zones + telomere decay

## Mid‑term (3–6 months)
- Demo: Echo‑style symbolic handshake + consent loop
- Integrations: local model interop; evaluation harness
- Ethics checklists and playbooks

## Long‑term
- Community governance expansion
- Reference implementations across frameworks
