# src

Place reference implementations, schemas, or adapters here.

Suggested subdirs:
- `memory/` — zone definitions, telomere decay policy
- `safety/` — limp-mode, interlocks
- `consent/` — consent loop handlers
