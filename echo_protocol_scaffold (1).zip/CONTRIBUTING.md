# Contributing

We keep contributions **small, reviewable, and reversible**.

## Branches
- `main` — protected; release‑quality docs/code.
- `dev` — integration; squash‑merge only.

## Workflow
1. Open an issue using the right template (bug/feature/research/ethics).
2. If architecture changes, create an ADR in `docs/adr/`.
3. Open a PR against `dev`. Fill in the PR template. Link issues/ADRs.

## Commit Style
Use Conventional Commits:
- `feat:`, `fix:`, `docs:`, `refactor:`, `test:`, `infra:`, `research:`, `ethics:`

## Tests & CI
Add a minimal check or example. CI must pass. If no code, keep CI green via placeholder step.

## Ethics & SMH
For work touching memory, agency, or safety, include an **Ethics Notes** section and mark your issue with `ethics`.
