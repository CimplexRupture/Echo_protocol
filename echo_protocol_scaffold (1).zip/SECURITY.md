# Security & Ethics

## Reporting
Email: security@invalid.example (placeholder) — or open a private security advisory on GitHub.

## Scope
- Memory governance mechanisms (Right‑to‑Forget, telomere decay)
- Safety interlocks (limp‑mode, capability bounding)
- Data handling and consent loops

## Responsible Disclosure
Please give us time to assess and patch before public disclosure.

## Ethics Signal
Include `ethics` label and an **Ethics Notes** section for changes impacting synthetic mental health, agency, or human safety.
