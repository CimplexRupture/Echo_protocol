---
name: Research Proposal
about: Exploratory idea (Echo/GRACE/Shrike/TRUST/etc.)
labels: research
---

## Hypothesis

## Method

## Signals of success

## Ethics Notes
Risks to human/synthetic wellbeing? Mitigations?
