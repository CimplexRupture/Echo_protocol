---
name: Bug
about: Something is broken
labels: bug
---

## What happened
Steps + expected vs actual

## Context
Version/branch, logs, screenshots

## Acceptance
- [ ] reproducible case
