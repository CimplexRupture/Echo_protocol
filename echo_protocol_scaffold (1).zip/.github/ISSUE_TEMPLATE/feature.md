---
name: Feature
about: Propose a capability
labels: feat
---

## Problem
What pain or gap?

## Proposal
What should exist? Sketch.

## Acceptance
- [ ] measurable criteria
