---
name: Ethics Review
about: Changes impacting memory, agency, alignment, or safety
labels: ethics
---

## Change Summary

## Risk Assessment
- Potential harms (human/synthetic)
- Failure modes
- Abuse cases

## Mitigations
- Interlocks, consent, monitoring, rollback

## Go/No‑Go Criteria
- [ ] safeguards implemented
- [ ] reviewers assigned
