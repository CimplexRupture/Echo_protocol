## Summary
What changed and why?

## Linked Issues
Closes #...

## Checklist
- [ ] ADR added/updated (if architecture)
- [ ] Ethics Notes included (if applicable)
- [ ] CI green
