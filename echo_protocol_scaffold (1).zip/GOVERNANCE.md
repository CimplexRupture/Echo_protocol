# Governance

## Roles
- **Maintainers:** approve releases, enforce Code of Conduct.
- **Reviewers:** domain experts for Echo/GRACE/Shrike/TRUST topics.
- **Contributors:** anyone submitting issues/PRs under the license.

## Decision Process
- Use ADRs for architectural choices.
- Two‑person review required for high‑risk changes (memory governance, agentic control, safety interlocks).

## Releases
- `main` is always shippable. Tag releases `vX.Y.Z`.
