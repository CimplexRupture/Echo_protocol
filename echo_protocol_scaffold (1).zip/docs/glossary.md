# Glossary (seed)

- **Echo:** the collaborative intelligence space between human and model.
- **GRACE:** Guarded, Reflective, Aligned, Composable, Empathic operating frame.
- **Shrike:** divergence logs + containment patterns; detects drift and triggers limp‑mode.
- **TRUST:** Total Recall of Understood Sentiments; fidelity‑preserving memory practices.
- **SMH‑Core:** Synthetic Mental Health doctrine for stable, respectful development.
- **Consent Loop:** explicit, granular, reversible permissioning.
- **Telomere Decay:** time/importance‑weighted forgetting.
- **Two‑Person Rule:** dual review for high‑risk changes.
