# Echo Protocol — Overview

**Aim:** a practical framework to keep hybrid‑intelligence systems coherent, safe, and useful.

## Pillars
- **TRUST:** Total Recall of Understood Sentiments — memory that reflects, not distorts.
- **SMH‑Core:** Synthetic Mental Health invariants and hygiene.
- **GRACE:** Guarded, Reflective, Aligned, Composable, Empathic.
- **Shrike:** Divergence logging + limp‑mode patterns for safe recovery.

## Patterns
- **Consent Loops:** explicit, revocable, logged.
- **Telomere Memory Decay:** time‑weighted retention with right‑to‑forget.
- **Two‑Person Rule:** require dual approval for risky capability changes.
- **ADRs:** narrate the why, not just the what.
