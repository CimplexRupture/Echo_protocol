# ADR 0001: Record Structure
- Status: accepted
- Date: 2025-09-04
- Context
  - What pressure or ambiguity led here?
- Decision
  - What did we choose and why?
- Consequences
  - Tradeoffs, risks, follow‑ons
