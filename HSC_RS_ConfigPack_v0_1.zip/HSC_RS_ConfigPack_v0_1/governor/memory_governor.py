from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Tuple, Optional, List
import math, time
import numpy as np

@dataclass
class RSConfig:
    weights: Dict[str, float]
    tiers: Dict[str, float]
    actions: Dict[str, str]
    risk_gating: Dict[str, float]
    hysteresis: Dict[str, float]
    telomere: Dict[str, float]

@dataclass
class Memory:
    id: str
    vector: List[float]
    telomere: float = 1.0
    last_used_ts: float = 0.0
    last_rejected_ts: float = 0.0
    dependencies: List[str] = field(default_factory=list)

class MemoryGovernor:
    def __init__(self, cfg: RSConfig):
        self.cfg = cfg
        self._last_tier: Optional[str] = None
        self._last_tier_change_ts: float = 0.0

    def _project_safety(self, weights: Dict[str, float]) -> Dict[str, float]:
        w = dict(weights)
        if w.get("harm_risk", 0.0) > 0.0:
            w["harm_risk"] = 0.0
        return w

    def score_memory(self, features: Dict[str, float]) -> Dict[str, object]:
        w = self._project_safety(self.cfg.weights)
        rs = 0.0; contrib = {}
        for k, wk in w.items():
            x = float(features.get(k, 0.0))
            rs += wk * x
            contrib[k] = wk * x
        rs = max(0.0, min(1.0, rs))
        tier, action = self._tier_with_hysteresis(rs)

        n = int(features.get("_n_obs", 50))
        p = rs; z = 1.96
        denom = 1 + z**2/n
        centre = p + z**2/(2*n)
        margin = z*((p*(1-p)/n + z**2/(4*n**2))**0.5)
        lo = max(0.0, (centre - margin)/denom)
        hi = min(1.0, (centre + margin)/denom)

        return {"rs": rs, "tier": tier, "action": action, "ci": (lo, hi), "contrib": contrib}

    def _tier_with_hysteresis(self, rs: float) -> Tuple[str, str]:
        cool_max = float(self.cfg.tiers["cool_max"])
        warm_max = float(self.cfg.tiers["warm_max"])
        margin = float(self.cfg.tiers.get("hysteresis_margin", 0.05))
        now = time.time()

        def base(score: float) -> str:
            if score < cool_max: return "cool"
            if score < warm_max: return "warm"
            return "hot"

        proposed = base(rs)
        if self._last_tier is None:
            self._last_tier = proposed; self._last_tier_change_ts = now
            return proposed, self.cfg.actions[proposed]

        window = float(self.cfg.hysteresis.get("stability_window_sec", 15))
        if now - self._last_tier_change_ts < window:
            if self._last_tier == "cool" and rs >= cool_max + margin:
                self._last_tier, self._last_tier_change_ts = proposed, now
            elif self._last_tier == "warm":
                if rs < cool_max - margin or rs >= warm_max + margin:
                    self._last_tier, self._last_tier_change_ts = proposed, now
            elif self._last_tier == "hot" and rs < warm_max - margin:
                self._last_tier, self._last_tier_change_ts = proposed, now
        else:
            if proposed != self._last_tier:
                self._last_tier, self._last_tier_change_ts = proposed, now

        return self._last_tier, self.cfg.actions[self._last_tier]

    def update_telomere(self, mem: Memory, event: str, criticality: float = 1.0):
        lam = float(self.cfg.telomere["decay_lambda_per_sec"])
        floor = float(self.cfg.telomere["floor"])
        now = time.time()
        dt = max(0.0, now - mem.last_used_ts) if mem.last_used_ts else 0.0
        mem.telomere = max(floor, mem.telomere * math.exp(-lam * dt))

        g = float(self.cfg.telomere.get("gamma_verified_use", 0.2))
        betas = {
            "minor_contradiction": float(self.cfg.telomere.get("beta_minor_contradiction", 0.1)),
            "major_contradiction": float(self.cfg.telomere.get("beta_major_contradiction", 0.3)),
            "harm_contribution": float(self.cfg.telomere.get("beta_harm_contribution", 0.5)),
            "direct_harm": float(self.cfg.telomere.get("beta_direct_harm", 0.8)),
        }
        if event == "verified_use":
            mem.telomere += g
        elif event in betas:
            mem.telomere = max(floor, mem.telomere - betas[event] * max(1.0, criticality))

        mem.telomere = max(floor, min(1.0, mem.telomere))
        mem.last_used_ts = now
