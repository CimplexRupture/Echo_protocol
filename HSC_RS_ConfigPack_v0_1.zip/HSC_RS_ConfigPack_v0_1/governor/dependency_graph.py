from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Set

@dataclass
class DepGraph:
    edges: Dict[str, List[str]] = field(default_factory=dict)

    def add_edge(self, parent: str, child: str):
        self.edges.setdefault(parent, []).append(child)

    def dependents(self, node: str) -> List[str]:
        return self.edges.get(node, [])

    def cascade(self, node: str) -> List[str]:
        out = []
        q = [node]
        seen: Set[str] = set([node])
        while q:
            cur = q.pop(0)
            for nxt in self.edges.get(cur, []):
                if nxt not in seen:
                    seen.add(nxt); out.append(nxt); q.append(nxt)
        return out
