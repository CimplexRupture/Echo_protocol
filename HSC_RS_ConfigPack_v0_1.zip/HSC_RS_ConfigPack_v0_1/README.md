# HSC RS Config Pack (v0.1)
Minimal, lean, self-checking pack for internal use.
See scripts/run_self_check.py to run built-in tests.
