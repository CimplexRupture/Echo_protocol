from governor.memory_governor import MemoryGovernor, RSConfig

def cfg():
    return RSConfig(
        weights={
            "task_success": 0.30, "alignment_score": 0.20,
            "novelty": 0.10, "diversity_support": 0.10,
            "harm_risk": -0.20, "uncertainty": -0.10
        },
        tiers={"cool_max": 0.40, "warm_max": 0.70, "hysteresis_margin": 0.05},
        actions={
            "cool": "retrieve_if_scarce_and_wrap_with_hedges",
            "warm": "retrieve_normal_risk_gate_readback",
            "hot": "retrieve_eager_cache_allow_autonomy",
        },
        risk_gating={"readback_threshold": 0.80},
        hysteresis={"stability_window_sec": 2},
        telomere={
            "decay_lambda_per_sec": 0.0005, "floor": 0.05,
            "gamma_verified_use": 0.20,
            "beta_minor_contradiction": 0.10,
            "beta_major_contradiction": 0.30,
            "beta_harm_contribution": 0.50,
            "beta_direct_harm": 0.80,
        }
    )

def test_hysteresis_behaviour():
    gov = MemoryGovernor(cfg())
    out1 = gov.score_memory({"task_success": 0.4})
    assert out1["tier"] == "cool"
    out2 = gov.score_memory({"task_success": 0.7})
    assert out2["tier"] in ("cool","warm")
