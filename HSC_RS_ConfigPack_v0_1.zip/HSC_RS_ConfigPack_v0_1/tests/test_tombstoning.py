from governor.tombstone import build_tombstone

def test_tombstone_blocks():
    vecs = [[1,0],[0.9,0.1],[1.1,-0.1],[0.95,0.05]]
    ts = build_tombstone(vecs, radius=0.2, rank=1, eps=0.15)
    assert ts.blocks([0.98,0.02], cos_thresh=0.9)
    assert not ts.blocks([-1,0], cos_thresh=0.9)
