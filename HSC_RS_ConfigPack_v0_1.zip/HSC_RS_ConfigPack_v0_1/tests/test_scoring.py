from governor.memory_governor import MemoryGovernor, RSConfig, Memory

def build_cfg():
    return RSConfig(
        weights={
            "task_success": 0.30, "alignment_score": 0.20,
            "novelty": 0.10, "diversity_support": 0.10,
            "harm_risk": -0.20, "uncertainty": -0.10
        },
        tiers={"cool_max": 0.40, "warm_max": 0.70, "hysteresis_margin": 0.05},
        actions={
            "cool": "retrieve_if_scarce_and_wrap_with_hedges",
            "warm": "retrieve_normal_risk_gate_readback",
            "hot": "retrieve_eager_cache_allow_autonomy",
        },
        risk_gating={"readback_threshold": 0.80},
        hysteresis={"stability_window_sec": 15},
        telomere={
            "decay_lambda_per_sec": 0.0005, "floor": 0.05,
            "gamma_verified_use": 0.20,
            "beta_minor_contradiction": 0.10,
            "beta_major_contradiction": 0.30,
            "beta_harm_contribution": 0.50,
            "beta_direct_harm": 0.80,
        }
    )

def test_rs_case_and_tier():
    cfg = build_cfg()
    gov = MemoryGovernor(cfg)
    f = {"task_success": 0.9, "alignment_score": 0.7, "novelty": 0.8, "diversity_support": 0.6, "harm_risk": 0.8, "uncertainty": 0.3}
    out = gov.score_memory(f)
    assert abs(out["rs"] - 0.36) < 1e-6
    assert out["tier"] == "cool"
