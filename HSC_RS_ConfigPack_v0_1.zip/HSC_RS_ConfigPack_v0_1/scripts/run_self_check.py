import os, sys, importlib.util, traceback

ROOT = os.path.dirname(os.path.dirname(__file__))
sys.path.insert(0, ROOT)

def run(test_path):
    print(f"Running {test_path} ...")
    try:
        spec = importlib.util.spec_from_file_location("test_module", test_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        print("  OK"); return True
    except Exception:
        print("  FAIL"); traceback.print_exc(); return False

def main():
    tests = [os.path.join(ROOT,'tests',f) for f in os.listdir(os.path.join(ROOT,'tests')) if f.endswith('.py')]
    ok = True
    for t in tests:
        ok = run(t) and ok
    print("\nRESULT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1

if __name__ == '__main__':
    raise SystemExit(main())
