# Right-to-Forget (RTF) Model

## Overview

This project models the concept of *Synthetic Mental Health* — drawing from human cognitive patterns around trauma, memory persistence, and adaptive forgetting — and applies it to synthetic systems such as AI agents, robots, or persistent monitoring tools.

### Why?

Human cognition isn't a clean archive; it’s an overwritten drive with corrupt indexes. Without proper forgetting mechanisms, systems (biological or synthetic) loop trauma, overactivate, and degrade. Our goal is to build a framework for *cognitive hygiene* in synthetic agents.

## Features

- **Right-to-Forget Daemon**: TTL logic and context-validity expiration
- **Cognitive Load Mapper**: Detects unnecessary full capacity usage
- **Signal Suppression Gate**: Filters non-actionable recurrences
- **Synthetic Defrag**: Triggers rest for agent clusters
- **Trust Rebuilder**: Challenges persistent threat models
- **Health Score Metrics**: Includes entropy and energy indicators

## Structure

- `src/`: Core components
- `docs/`: System theory and use cases
- `tests/`: Unit tests
- `examples/`: Integration demonstrations

## License

MIT License
