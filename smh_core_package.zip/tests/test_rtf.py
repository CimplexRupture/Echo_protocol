import time
from src.rtf_daemon import RightToForgetDaemon

def test_rtf():
    rtf = RightToForgetDaemon(ttl_seconds=1)
    rtf.register_event("threat_001")
    time.sleep(2)
    forgotten = rtf.forget_expired()
    assert "threat_001" in forgotten
