# smh_core init
