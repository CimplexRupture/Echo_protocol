
# HSC Sim – LEAN Mode (Control Tower)

Simplified variant for soak tests:
- **Risk**: boolean flags → derived RA
- **ES tiers**: GREEN / RED (FAILSAFE reserved)
- **Audit**: flat JSONL (no hash chain)

## Run
```bash
python -m hsc_sim_lean.main
```
Outputs pass/fail and writes `audit.jsonl`.
