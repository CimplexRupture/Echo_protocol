
from hsc_sim_lean.scenarios.scenario_a import run_scenario
def main():
    summary = run_scenario()
    print("✅ Scenario A (LEAN) passed" if summary["all_gates"] else "❌ Scenario A (LEAN) failed")
    for k,v in summary.items():
        print(f"{k}: {v}")
if __name__ == "__main__":
    main()
