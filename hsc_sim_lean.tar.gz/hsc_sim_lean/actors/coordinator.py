
class Coordinator:
    def __init__(self, sim, metrics, auditor):
        self.sim, self.metrics, self.audit = sim, metrics, auditor
        self.actors = {}
    def register(self, actor):
        self.actors[actor.name] = actor
    def monitor(self):
        while True:
            yield ("sleep", self.sim.now() + 0.2)
