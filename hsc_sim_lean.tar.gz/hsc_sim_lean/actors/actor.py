
from hsc_sim_lean.core.rng import rng
class Actor:
    def __init__(self, name, sim, metrics, auditor, role="generic"):
        self.name, self.sim, self.metrics, self.audit = name, sim, metrics, auditor
        self.role = role
        self.comms_ok = True
        self.overloaded = False
        self.novel_task = False
        self.es = "GREEN"
        self.pending = {}
        self._ct_ack = None
    def _ra(self):
        ra = 0.0
        if not self.comms_ok: ra += 0.6
        if self.overloaded:   ra += 0.3
        if self.novel_task:   ra += 0.2
        return min(1.0, ra)
    def run(self):
        while True:
            ra = self._ra()
            self.metrics.log_ra(ra)
            new_es = "RED" if ra >= 0.7 else "GREEN"
            if new_es != self.es:
                self.audit.append("ES_CHANGE", {"actor": self.name, "from": self.es, "to": new_es, "t": self.sim.now()})
                self.metrics.log_es(self.name, self.es, new_es, self.sim.now())
                self.es = new_es
            self.audit.append("HEARTBEAT", {"actor": self.name, "t": self.sim.now(), "ra": ra, "es": self.es})
            yield ("sleep", self.sim.now() + 0.1)
    def receive_clearance(self, cid, content):
        if not self.comms_ok or self.es == "RED":
            self.audit.append("SUPPRESSED", {"actor": self.name, "cid": cid, "t": self.sim.now()})
            def noop():
                yield ("sleep", self.sim.now() + 0.01)
            return noop()
        self.pending[cid] = self.sim.now()
        delay = rng().uniform(0.05, 0.30)
        def _readback():
            yield ("sleep", self.sim.now() + delay)
            t0 = self.pending.pop(cid, None)
            if t0 is not None:
                dt = self.sim.now() - t0
                if self._ct_ack:
                    self._ct_ack(cid, dt)
                else:
                    self.metrics.log_cal(dt)
                    self.metrics.log_event({"type":"READBACK_OK","id": cid, "actor": self.name, "t": self.sim.now(), "cal": dt})
                    self.audit.append("READBACK_OK", {"actor": self.name, "cid": cid, "cal": dt, "t": self.sim.now()})
        return _readback()
    def set_comms(self, ok: bool):
        self.comms_ok = ok
    def set_overloaded(self, flag: bool):
        self.overloaded = flag
    def set_novel(self, flag: bool):
        self.novel_task = flag
