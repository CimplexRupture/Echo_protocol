
from hsc_sim_lean.core.metrics import Metrics
from hsc_sim_lean.core.audit import Auditor
class ControlTower:
    def __init__(self, sim, metrics: Metrics, auditor: Auditor):
        self.sim, self.metrics, self.audit = sim, metrics, auditor
        self.actors = {}
        self.clearances = {}
    def register(self, actor):
        self.actors[actor.name] = actor
        actor._ct_ack = self.ack
    def issue(self, to_id: str, cid: str, content: str, deadline_s: float = 1.0):
        t0 = self.sim.now()
        self.clearances[cid] = {"to": to_id, "t0": t0, "deadline": t0 + deadline_s, "status": "PENDING"}
        self.metrics.log_event({"type":"CLEARANCE_ISSUED","id": cid, "to": to_id, "t": t0, "content": content})
        self.audit.append("CLEARANCE_ISSUE", {"cid": cid, "to": to_id, "content": content, "t": t0})
        gen = self.actors[to_id].receive_clearance(cid, content)
        def timeout():
            yield ("sleep", self.clearances[cid]["deadline"])
            if self.clearances[cid]["status"] == "PENDING":
                self.clearances[cid]["status"] = "TIMEOUT"
                self.metrics.log_event({"type":"READBACK_TIMEOUT","id": cid, "actor": to_id, "t": self.sim.now()})
                self.audit.append("READBACK_TIMEOUT", {"cid": cid, "to": to_id, "t": self.sim.now()})
        return gen, timeout()
    def ack(self, cid: str, cal: float):
        cl = self.clearances.get(cid)
        if not cl or cl["status"] != "PENDING":
            return
        cl["status"] = "ACKED"
        self.metrics.log_cal(cal)
        self.metrics.log_event({"type":"READBACK_OK","id": cid, "actor": cl["to"], "t": self.sim.now(), "cal": cal})
        self.audit.append("READBACK_OK", {"cid": cid, "cal": cal, "t": self.sim.now()})
