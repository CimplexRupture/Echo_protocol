
import json, time, os
class Auditor:
    def __init__(self, path="audit.jsonl"):
        self.path = path
        try: os.remove(path)
        except FileNotFoundError: pass
    def append(self, kind: str, payload: dict):
        rec = {"ts": time.time(), "kind": kind, "payload": payload}
        with open(self.path, "a") as f:
            f.write(json.dumps(rec, sort_keys=True) + "\n")
    def finalize_run(self, summary: dict):
        self.append("RUN_SUMMARY", summary)
        return None
