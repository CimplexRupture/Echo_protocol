
import random
class RNG:
    def __init__(self, seed: int = 0):
        self._rng = random.Random(seed)
    def seed(self, seed: int):
        self._rng.seed(seed)
    def uniform(self, a: float, b: float) -> float:
        return self._rng.uniform(a, b)
_rng = RNG(0)
def seed_all(seed: int):
    _rng.seed(seed)
def rng() -> RNG:
    return _rng
