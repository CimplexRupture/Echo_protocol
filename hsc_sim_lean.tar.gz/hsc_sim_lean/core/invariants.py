
def gate_cal_p95(metrics, limit_s): 
    return metrics.p95_cal() <= float(limit_s)
def gate_ra_max(metrics, limit):   
    return metrics.ra_max < float(limit)
def gate_audit_complete(events):
    issued = {e["id"] for e in events if e.get("type")=="CLEARANCE_ISSUED"}
    closed  = {e["id"] for e in events if e.get("type") in ("READBACK_OK","READBACK_TIMEOUT")}
    return issued <= closed
