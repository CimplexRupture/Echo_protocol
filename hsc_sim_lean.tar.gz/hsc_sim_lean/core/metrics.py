
class Metrics:
    def __init__(self):
        self.cal = []
        self.ra_max = 0.0
        self.es_transitions = []
        self.events = []
    def log_cal(self, dt): self.cal.append(float(dt))
    def log_ra(self, v): self.ra_max = max(self.ra_max, float(v))
    def log_es(self, actor, frm, to, t): self.es_transitions.append((actor, frm, to, float(t)))
    def log_event(self, e): self.events.append(dict(e))
    def p95_cal(self):
        if not self.cal: return 0.0
        xs = sorted(self.cal); k = int(0.95*(len(xs)-1))
        return xs[k]
