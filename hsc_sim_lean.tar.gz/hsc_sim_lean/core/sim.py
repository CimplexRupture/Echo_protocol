
import heapq
from dataclasses import dataclass, field
from typing import Any

@dataclass(order=True)
class ScheduledTask:
    when: float
    seq: int
    gen: Any=field(compare=False)

class Sim:
    def __init__(self, tick: float = 0.05):
        self.time = 0.0
        self.tick = tick
        self._q = []
        self._seq = 0

    def now(self) -> float:
        return self.time

    def spawn(self, gen):
        import heapq
        heapq.heappush(self._q, ScheduledTask(self.time, self._seq, gen))
        self._seq += 1

    def run(self, until: float = None, max_steps: int = 100000):
        import heapq
        steps = 0
        while self._q and steps < max_steps:
            task = heapq.heappop(self._q)
            self.time = max(self.time, task.when)
            try:
                yielded = next(task.gen)
                if isinstance(yielded, tuple) and yielded and yielded[0] == "sleep":
                    wake = float(yielded[1])
                    heapq.heappush(self._q, ScheduledTask(wake, self._seq, task.gen))
                    self._seq += 1
                else:
                    heapq.heappush(self._q, ScheduledTask(self.time, self._seq, task.gen))
                    self._seq += 1
            except StopIteration:
                pass
            steps += 1
            if until is not None and self.time >= until:
                break
        return {"sim_time": self.time, "steps": steps, "remaining": len(self._q)}
