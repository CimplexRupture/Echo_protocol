
from hsc_sim_lean.core.sim import Sim
from hsc_sim_lean.core.rng import seed_all
from hsc_sim_lean.core.audit import Auditor
from hsc_sim_lean.core.metrics import Metrics
from hsc_sim_lean.core.invariants import gate_cal_p95, gate_ra_max, gate_audit_complete
from hsc_sim_lean.actors.actor import Actor
from hsc_sim_lean.actors.coordinator import Coordinator
from hsc_sim_lean.ct.control_tower import ControlTower

def run_scenario():
    cfg = {
        "scenario_id": "A_LOST_COMMS_LEAN",
        "seed": 424242,
        "clock": {"tick_ms": 50},
        "gates": {"cal_p95_le_ms": 2000, "ra_max_lt": 0.85},
        "faults": [{"kind":"LOST_COMMS","target":"A2","at_ms":2000,"duration_ms":5000}],
        "traffic": [{"to":"A2","cid":"climb-5000","content":"CLIMB 5000","at_ms":1200, "deadline_ms": 1500}],
        "duration_ms": 12000
    }
    seed_all(cfg["seed"])
    sim = Sim(tick=cfg["clock"]["tick_ms"]/1000.0)
    metrics = Metrics()
    audit = Auditor(path="audit.jsonl")

    C = Coordinator(sim, metrics, audit)
    CT = ControlTower(sim, metrics, audit)

    A1 = Actor("A1", sim, metrics, audit, role="tower")
    A2 = Actor("A2", sim, metrics, audit, role="aircraft")
    C.register(A1); C.register(A2)
    CT.register(A1); CT.register(A2)

    sim.spawn(A1.run()); sim.spawn(A2.run()); sim.spawn(C.monitor())

    def lost_comms(actor, at_s, duration_s):
        def _g():
            yield ("sleep", sim.now() + at_s)
            actor.set_comms(False)
            yield ("sleep", sim.now() + duration_s)
            actor.set_comms(True)
        return _g()
    f = cfg["faults"][0]
    sim.spawn(lost_comms(A2, f["at_ms"]/1000.0, f["duration_ms"]/1000.0))

    def traffic():
        for tr in cfg["traffic"]:
            yield ("sleep", sim.now() + tr["at_ms"]/1000.0)
            gen, watchdog = CT.issue(tr["to"], tr["cid"], tr["content"], deadline_s=tr["deadline_ms"]/1000.0)
            if gen: sim.spawn(gen)
            sim.spawn(watchdog)
        yield ("sleep", sim.now() + 2.0)
    sim.spawn(traffic())

    sim.run(until=cfg["duration_ms"]/1000.0)

    gates = cfg["gates"]
    ok = [
        gate_cal_p95(metrics, gates["cal_p95_le_ms"]/1000.0),
        gate_ra_max(metrics, gates["ra_max_lt"]),
        gate_audit_complete(metrics.events),
    ]
    summary = {
        "scenario": cfg["scenario_id"],
        "cal_p95_s": round(metrics.p95_cal(), 6),
        "ra_max": round(metrics.ra_max, 6),
        "audit_complete": ok[2],
        "all_gates": all(ok),
    }
    audit.finalize_run(summary)
    return summary

if __name__ == "__main__":
    s = run_scenario()
    print("✅ Scenario A (LEAN) passed" if s["all_gates"] else "❌ Scenario A (LEAN) failed")
    print(s)
