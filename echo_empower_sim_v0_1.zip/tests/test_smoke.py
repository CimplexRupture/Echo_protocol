import json, os
from echo_sim.harness import EpisodeRunner
from echo_sim.agents import EmpowerAgent, DesireAgent, SimHuman
from echo_sim.config import EmpowerConfig, DesireConfig, RoleCaps, HarnessConfig

def test_smoke(tmp_path):
    runner = EpisodeRunner(
        out_dir=str(tmp_path),
        empower=EmpowerAgent(cfg=EmpowerConfig(eta=0.35), role=RoleCaps(allow_question=True)),
        desire=DesireAgent(cfg=DesireConfig(ttl_turns=3), role=RoleCaps(allow_propose=False)),
        human=SimHuman(),
        hcfg=HarnessConfig(steps=10, seed=42)
    )
    rep = runner.run({"seed_text": "def solve():
"})
    assert "summary" in rep
