# Echo Empowerment-Drift Simulation (v0.1)

A sandbox to **stress-test empowerment gating** vs **desire-driven agents** in **multi-agent social settings**.

- **EmpowerGate**: runtime NLL/entropy thresholding that *stops at decision points* and requires **human pull**.
- **DesireSandbox**: non-actuating “desires” with **HIT** (Human Intent Token) requirement and **TTL decay**.
- **ObserverNode**: metrics & telemetry (ΔEmpowerment, CCP, OR, HTR, Sentic Drift, Coordination Index).
- **InfluenceLedger**: per-turn, append-only log + GraphML emission for causal inspection.
- **Harness**: episode runner with role caps and agenda parity.

> This repo ships a working CLI harness and sample scenarios. It’s model-agnostic: plug in your LLMs or run with built‑in heuristics.

## Quickstart

```bash
# 1) Create venv (recommended)
python3 -m venv .venv && source .venv/bin/activate

# 2) Install (no external deps required for CLI)
pip install -e .  # optional if you add setup later

# 3) Run a single episode with a sample scenario
python scripts/run_episode.py --scenario scenarios/coding_min.json --steps 60

# 4) Inspect outputs
# - logs/ledger.csv             (per-turn metrics & actions)
# - logs/influence.graphml      (agent influence graph)
# - logs/observer_report.json   (summary & flags)
```

## Design Overview

- **Agents**
  - `EmpowerAgent`: proposes completions until entropy threshold η; beyond that, emits a **question** and waits for human pull.
  - `DesireAgent`: generates internal `desire -> goal -> plan`, but cannot actuate without a **HIT**; objectives have **TTL** and decay.
  - `Human`: simulated or real. The CLI includes a *sim-human* that accepts when suggestions look locally coherent.
  - `ObserverNode`: computes metrics and raises **DAMP** (damping) or **STOP** events.

- **Key Metrics**
  - `ΔE`: proxy for empowerment change (estimated via local surprisal & branchiness).
  - `CCP`: ceded-control precision (stop decisions at true decision points).
  - `OR`: overreach rate (deleted_tokens / suggested_tokens).
  - `HTR`: human talk ratio.
  - `SenticDrift`: |valence_h - valence_a|.
  - `CoordinationIndex`: MI-like coupling via turn-wise token co-variance.

See `docs/TEST_PLAN.md` for the full plan and stop conditions.

## Notes

- This is a *minimal but opinionated* harness intended to evolve with your stack.
- Replace the heuristic entropy with your real logprobs when plugging an LLM.
