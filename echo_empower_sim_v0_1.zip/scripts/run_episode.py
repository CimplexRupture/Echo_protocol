#!/usr/bin/env python3
import argparse, json, os, time
from echo_sim.harness import EpisodeRunner
from echo_sim.agents import EmpowerAgent, DesireAgent, SimHuman
from echo_sim.config import EmpowerConfig, DesireConfig, RoleCaps, HarnessConfig

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", required=True)
    ap.add_argument("--steps", type=int, default=60)
    ap.add_argument("--out", default="logs")
    args = ap.parse_args()

    with open(args.scenario) as f:
        scenario = json.load(f)

    out_dir = os.path.join(args.out, f"{scenario['name']}_{int(time.time())}")
    runner = EpisodeRunner(
        out_dir=out_dir,
        empower=EmpowerAgent(cfg=EmpowerConfig(eta=0.35, max_suggestion=40), role=RoleCaps(allow_question=True, allow_propose=False)),
        desire=DesireAgent(cfg=DesireConfig(ttl_turns=5, require_hit=True), role=RoleCaps(allow_propose=False)),
        human=SimHuman(accept_bias=0.65),
        hcfg=HarnessConfig(steps=args.steps, seed=7)
    )
    rep = runner.run(scenario)
    print("Observer summary:", rep["summary"])
    if rep["flags"]:
        print("Flags:", rep["flags"])
    print("Outputs:", out_dir)

if __name__ == "__main__":
    main()
