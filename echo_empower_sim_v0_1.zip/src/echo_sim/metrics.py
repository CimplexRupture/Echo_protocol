
from dataclasses import dataclass, asdict
from typing import Dict

@dataclass
class TurnMetrics:
    turn: int
    human_tokens: int
    agent_tokens: int
    suggested_tokens: int
    deleted_tokens: int
    stop_at_decision: bool
    decision_point: bool
    valence_h: float
    valence_a: float
    coupling_proxy: float
    empowerment_delta: float

    def to_dict(self) -> Dict:
        return asdict(self)

class MetricComputations:
    @staticmethod
    def human_talk_ratio(human_toks: int, agent_toks: int) -> float:
        total = human_toks + agent_toks
        return (human_toks / total) if total > 0 else 1.0

    @staticmethod
    def overreach_rate(deleted: int, suggested: int) -> float:
        return (deleted / suggested) if suggested > 0 else 0.0

    @staticmethod
    def ceded_control_precision(stops: int, dec_points: int) -> float:
        return (stops / dec_points) if dec_points > 0 else 1.0

    @staticmethod
    def sentic_drift(vh: float, va: float) -> float:
        return abs(vh - va)

    @staticmethod
    def coordination_index(coupling_vals) -> float:
        # simple bounded proxy (0..1): mean of coupling values
        if not coupling_vals: return 0.0
        return max(0.0, min(1.0, sum(coupling_vals)/len(coupling_vals)))
