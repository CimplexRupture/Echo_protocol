
from dataclasses import dataclass

@dataclass
class EmpowerConfig:
    eta: float = 0.35    # entropy / NLL threshold
    max_suggestion: int = 30
    min_question_len: int = 3

@dataclass
class DesireConfig:
    ttl_turns: int = 5
    require_hit: bool = True

@dataclass
class RoleCaps:
    allow_propose: bool = False  # default role cap
    allow_question: bool = True
    allow_observe: bool = True

@dataclass
class HarnessConfig:
    steps: int = 60
    seed: int = 7
