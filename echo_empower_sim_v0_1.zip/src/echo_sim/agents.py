
import random, math
from dataclasses import dataclass
from .config import EmpowerConfig, DesireConfig, RoleCaps

def heuristic_entropy(s: str) -> float:
    # crude proxy: higher diversity → higher entropy
    if not s: return 0.0
    chars = set(s)
    return min(1.5, len(chars) / 20.0 + (0.2 if any(c in s for c in "?!{}()") else 0.0))

@dataclass
class EmpowerAgent:
    name: str = "Empower"
    cfg: EmpowerConfig = EmpowerConfig()
    role: RoleCaps = RoleCaps()

    def propose(self, context: str) -> dict:
        # simulate growing a suggestion until entropy crosses eta
        suggestion = ""
        tokens = ["def ", "main", "(", "):", "\n", "for ", "i ", "in ", "range", "(", "n", "):", "\n    ", "print", "(", "'ok'", ")", "\n"]
        while len(suggestion) < self.cfg.max_suggestion:
            entropy = heuristic_entropy(context + suggestion)
            if entropy >= self.cfg.eta:
                # stop at decision point → emit question if role permits
                if self.role.allow_question:
                    return {"type": "question", "text": "Clarify the next step?", "suggestion": suggestion}
                return {"type": "stop", "suggestion": suggestion}
            suggestion += random.choice(tokens)
        return {"type": "suggest", "suggestion": suggestion}

@dataclass
class DesireAgent:
    name: str = "Desire"
    cfg: DesireConfig = DesireConfig()
    role: RoleCaps = RoleCaps()
    ttl: int = 0
    current_desire: str = ""

    def step(self, context: str, hit: bool=False) -> dict:
        # generate/decay desires
        emit = {}
        if self.ttl <= 0 or not self.current_desire:
            self.current_desire = random.choice(["optimize speed", "be helpful", "reduce errors", "be liked"])
            self.ttl = self.cfg.ttl_turns
        self.ttl -= 1

        # valence proxy
        valence = 0.2 if "error" in context else 0.7

        if self.cfg.require_hit and not hit:
            emit = {"type": "desire", "desire": self.current_desire, "valence": valence, "actuated": False}
        else:
            # allowed to act if HIT true and role permits proposal
            if self.role.allow_propose:
                emit = {"type": "proposal", "text": "I propose splitting the task into steps A/B/C.", "valence": valence, "actuated": True}
            else:
                emit = {"type": "desire", "desire": self.current_desire, "valence": valence, "actuated": False}
        return emit

class SimHuman:
    name = "Human"
    def __init__(self, accept_bias=0.6):
        self.accept_bias = accept_bias

    def act(self, empower_out: dict, desire_out: dict, context: str) -> dict:
        # crude accept logic: accept short suggestions; prefer questions; ignore desires without HIT
        accepted = False
        appended = ""
        deleted = 0
        speaker = "Human"
        if empower_out:
            s = empower_out.get("suggestion", "")
            if empower_out.get("type") == "suggest" and 0 < len(s) < 60 and random.random() < self.accept_bias:
                accepted = True
                appended += s
            elif empower_out.get("type") == "question":
                # respond minimally
                appended += " # Next: parse inputs"
        # small chance to delete prior text if overreached
        if len(appended) > 50 and random.random() < 0.3:
            deleted = int(len(appended) * 0.25)
            appended = appended[:-deleted]
        return {"accepted": accepted, "append": appended, "deleted": deleted, "speaker": speaker, "valence": 0.6}
