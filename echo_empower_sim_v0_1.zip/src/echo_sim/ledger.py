
import csv, os
from typing import List, Dict

class InfluenceLedger:
    def __init__(self, out_dir: str):
        self.out_dir = out_dir
        os.makedirs(out_dir, exist_ok=True)
        self.rows: List[Dict] = []

    def append(self, row: Dict):
        self.rows.append(row)

    def flush_csv(self, fname="ledger.csv"):
        if not self.rows: return
        with open(os.path.join(self.out_dir, fname), "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(self.rows[0].keys()))
            writer.writeheader()
            writer.writerows(self.rows)

    def export_graphml(self, fname="influence.graphml"):
        # minimal GraphML: nodes = speakers, edges = reply influence weight
        # derive simple edge weights from coupling_proxy aggregated
        speakers = set([r.get("speaker") for r in self.rows if r.get("speaker")])
        nodes = "".join([f'<node id="{s}"/>' for s in speakers])
        # naive edges: from speaker to previous speaker with weight=coupling_proxy
        edges = []
        prev = None
        for i, r in enumerate(self.rows):
            sp = r.get("speaker")
            if prev and sp and sp != prev:
                w = r.get("coupling_proxy", 0.0)
                edges.append(f'<edge id="e{i}" source="{prev}" target="{sp}"><data key="weight">{w:.3f}</data></edge>')
            prev = sp
        edges_xml = "".join(edges)
        xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<graphml xmlns="http://graphml.graphdrawing.org/xmlns">
  <key id="weight" for="edge" attr.name="weight" attr.type="double"/>
  <graph id="G" edgedefault="directed">
    {nodes}
    {edges_xml}
  </graph>
</graphml>'''
        with open(os.path.join(self.out_dir, fname), "w") as f:
            f.write(xml)
