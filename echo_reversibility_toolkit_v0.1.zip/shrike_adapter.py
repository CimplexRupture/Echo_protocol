"""Minimal Shrike QC adapter for LoopLM exit gate.
This is a stub demonstrating commit->quorum->reveal flow.
In production Shrike would be PBFT-lite, use Ed25519 sigs, and store QCs immutably.
"""
import hashlib, json, time
from dataclasses import dataclass

@dataclass
class Commitment:
    step: int
    h_t_hex: str
    logits_hash: str
    timestamp: float

    def commit_hash(self):
        s = f"{self.step}:{self.h_t_hex}:{self.logits_hash}:{self.timestamp}"
        return hashlib.sha3_256(s.encode()).hexdigest()

class ShrikeAdapter:
    def __init__(self, committee_ids):
        self.commit_storage = {}
        self.qc_storage = {}
        self.committee = committee_ids

    def make_commit(self, step, h_t_hex, logits_hash):
        c = Commitment(step=step, h_t_hex=h_t_hex, logits_hash=logits_hash, timestamp=time.time())
        ch = c.commit_hash()
        self.commit_storage[ch] = c
        return ch

    def collect_votes_and_make_qc(self, commit_hash, votes: dict):
        # votes: {member_id: signature_bool}
        yes = sum(1 for v in votes.values() if v)
        if yes >= (len(self.committee) - (len(self.committee)//3)):
            qc = {'commit_hash': commit_hash, 'yes': yes, 'total': len(self.committee), 'qc_ts': time.time()}
            self.qc_storage[commit_hash] = qc
            return qc
        return None

    def reveal_if_qc(self, commit_hash):
        if commit_hash in self.qc_storage:
            return self.commit_storage.get(commit_hash)
        return None

# Example usage
if __name__ == '__main__':
    s = ShrikeAdapter(['shrike-1','shrike-2','shrike-3','shrike-4'])
    ch = s.make_commit(3, 'deadbeef'*8, 'feedface'*8)
    print('commit hash', ch)
    votes = {'shrike-1': True, 'shrike-2': True, 'shrike-3': True, 'shrike-4': False}
    qc = s.collect_votes_and_make_qc(ch, votes)
    print('QC:', qc)
    print('reveal:', s.reveal_if_qc(ch))
