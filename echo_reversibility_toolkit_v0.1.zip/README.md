Echo Reversibility Toolkit v0.1
------------------------------
Files:
- ops_registry.yaml : example registry
- ops_registry_schema.json : light JSON schema for ops registry
- channel_contract_schema.json : channel contract schema (light)
- audit_record_schema.json : audit record delta schema (light)
- pri_mdl.py : PRI composite and MDL-adjusted R* reference code
- shrike_adapter.py : minimal Shrike QC adapter (commit/quorum/reveal)
- challenge_api_stub.py : minimal Flask stub for Challenge–Invert API
- red_team_harness.py : red-team harness stubs
- calibration_outline.md : calibration & evaluation notebook outline

How to use:
1. Inspect ops_registry.yaml and adapt to your environment.
2. Run pri_mdl.py for reference calculations and unit tests.
3. Deploy challenge_api_stub.py behind an internal auth gateway for challenge orchestration.
4. Integrate shrike_adapter.py with your metric store to perform commit->QC->reveal on exit decisions.
5. Use red_team_harness.py to generate adversarial traces in CI.

License: CC-BY-NC for prototyping within Echo consortium.
