"""PRI and MDL tools (reference) - Echo Toolkit v0.1
Lightweight reference implementations for PRI window and MDL-adjusted R*.
"""
from dataclasses import dataclass
from typing import List, Dict
import math

@dataclass
class ChallengeResult:
    ok: bool
    latency_ms: float
    op_family_id: str
    weight: float  # influence weight for composite PRI

@dataclass
class PriWindow:
    results: List[ChallengeResult]

    def op_family_pri(self) -> Dict[str, float]:
        fam = {}
        for r in self.results:
            ok, total = fam.get(r.op_family_id, (0, 0))
            fam[r.op_family_id] = (ok + int(r.ok), total + 1)
        return {f: ok/total for f,(ok,total) in fam.items() if total>0}

    def composite_pri(self) -> float:
        fam_pri = self.op_family_pri()
        weights = {}
        for r in self.results:
            weights[r.op_family_id] = weights.get(r.op_family_id, 0.0) + r.weight
        val = 1.0
        Z = sum(weights.values()) or 1.0
        for f, pri in fam_pri.items():
            w = weights.get(f, 0.0)/Z
            val *= (pri ** w) if pri>0 else 0.0
        return val

def mdl_adjusted_R(R: float, audit_overhead_bits: float, useful_state_bits: float, lam: float, eps: float=1.0) -> float:
    """R* = max(0, R - lam * (audit_overhead_bits / (useful_state_bits + eps)))
    Simple, deterministic reference implementation.
    """
    ratio = audit_overhead_bits / (useful_state_bits + eps)
    return max(0.0, R - lam * ratio)

# small sanity tests
if __name__ == '__main__':
    res = [ChallengeResult(ok=True, latency_ms=120, op_family_id='summarize.v2', weight=1.0),
           ChallengeResult(ok=False, latency_ms=350, op_family_id='redact.pii.v1', weight=0.5),
           ChallengeResult(ok=True, latency_ms=90, op_family_id='summarize.v2', weight=1.0)]
    w = PriWindow(results=res)
    print('per-family PRI:', w.op_family_pri())
    print('composite PRI:', w.composite_pri())
    print('R* example:', mdl_adjusted_R(R=0.86, audit_overhead_bits=1024, useful_state_bits=8192, lam=0.6))
