# Calibration & Evaluation Notebook - Outline

This notebook outlines steps to calibrate and evaluate LoopLM + Echo toolkit.

Sections:
1. Load model checkpoints and Ops Registry
2. Instrument model to emit per-step audit records
3. Compute ECE and Brier per-step across datasets
4. Run PRI challenge windows and compute composite PRI
5. Compute MDL-adjusted R* and plot R vs R*
6. Run red-team scenarios and measure rupture detection (BOCPD/CUSUM)
7. Hyperparameter sweep for G.R.A.C.E. VoC threshold
8. Produce dashboard charts: waterfall, Sankey for info flow, R(t) trace

Notes:
- Use 1K samples for quick iteration; scale to 50K for production metrics.
- Keep canary pool separate from evaluation holdout.
