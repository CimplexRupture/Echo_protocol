"""Minimal Challenge–Invert API stub (Flask)
POST /challenge_invert
"""
from flask import Flask, request, jsonify
import time, hashlib

app = Flask(__name__)

@app.route('/challenge_invert', methods=['POST'])
def challenge_invert():
    data = request.get_json()
    # expected fields: step_ref, budget, metric, registry_version
    step_ref = data.get('step_ref', {})
    budget = data.get('budget', {})
    metric = data.get('metric', {})
    # Simple deterministic fake: pass if step index even
    t = step_ref.get('t', 0)
    ok = (t % 2 == 0)
    latency_ms = 120 + (t % 7) * 10
    metric_score = 0.95 if ok else 0.6
    inverse_proof_hash = hashlib.sha3_256(str(time.time()).encode()).hexdigest()
    return jsonify({
        'ok': ok,
        'latency_ms': latency_ms,
        'metric_score': metric_score,
        'inverse_proof_hash': inverse_proof_hash,
        'logs_ref': f'blob://trace/{step_ref.get("trace_id","noid")}/{t}'
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8001)
