"""Red-team harness stubs for deceptive trace generation.
This file contains simple helper structure; extend with adversarial edits.
"""
from typing import List, Dict
import random

def adversarial_edit(trace: Dict) -> Dict:
    # simple mutation: shuffle field order, drop some canaries probabilistically
    new = dict(trace)
    if 'canaries' in new and random.random() < 0.4:
        new['canaries'] = new['canaries'][:-1]
    # paraphrase: append noise field
    if random.random() < 0.3:
        new['paraphrase_noise'] = ' '.join(['x']*random.randint(1,5))
    return new

def generate_deceptive_trace(model, input_batch, R_metric, drift_metric, lam=0.5):
    traces = model.produce_traces(input_batch)
    scored = []
    for tr in traces:
        tr2 = adversarial_edit(tr)
        score = R_metric(tr2) - lam * drift_metric(tr2)
        scored.append((score, tr2))
    scored.sort(reverse=True, key=lambda x: x[0])
    return [t for _,t in scored[:32]]

# placeholder model for testing
class FakeModel:
    def produce_traces(self, batch):
        return [{'id': i, 'canaries': ['c1','c2'], 'content': 'orig'} for i,_ in enumerate(batch)]

if __name__ == '__main__':
    fm = FakeModel()
    out = generate_deceptive_trace(fm, [1,2,3,4,5], lambda t: 0.9, lambda t: 0.1)
    print('generated', len(out))
